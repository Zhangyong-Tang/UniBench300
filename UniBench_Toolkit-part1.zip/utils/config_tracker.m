function trackers = config_tracker()
    trackers = {
          struct('name', 'BAT',           'publish', 'vipe');
          struct('name', 'SPT',           'publish', 'vipe');
          struct('name', 'TENet',           'publish', 'vipe');
          struct('name', 'GMMT',           'publish', 'vipe');
          struct('name', 'TBSI',           'publish', 'vipe');
          struct('name', 'SymTrack+CL',           'publish', 'vipe');
          struct('name', 'SymTrack-D',           'publish', 'vipe');
          struct('name', 'SymTrack-T',           'publish', 'vipe');
          struct('name', 'SymTrack-E',           'publish', 'vipe');
          struct('name', 'ViPT+CL',           'publish', 'vipe');
          struct('name', 'ViPT+mixed',           'publish', 'vipe');
          struct('name', 'ViPT-D',           'publish', 'vipe');
          struct('name', 'ViPT-T',           'publish', 'vipe');
          struct('name', 'ViPT-E',           'publish', 'vipe');
          struct('name', 'SDSTrack-D',           'publish', 'vipe');
          struct('name', 'SDSTrack-T',           'publish', 'vipe');
          struct('name', 'SDSTrack-E',           'publish', 'vipe');
          struct('name', 'SymTrack+mixed',           'publish', 'vipe');

        };
end







